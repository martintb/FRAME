# This file is auto-generated during the build process
__version__ = "0.3.1"
